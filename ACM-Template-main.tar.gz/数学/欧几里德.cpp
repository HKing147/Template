{ return b ? gcd(b, a % b) : a; }
}
