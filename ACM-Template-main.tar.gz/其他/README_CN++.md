前提:安装好 xelatex

> ```shell
>  git clone https://github.com/HKing147/ACM-Template.git
> ```
>
> ```shell
> cd ACM-template/.fonts/
> cp ./* /usr/share/fonts/
> mkfontscale
> mkfontdir
> fc-cache
> ```
>
> ```shell
> cd ..
> make
> ```

使用
